package com.example.projecttwo;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements InventoryAdapter.OnDeleteClickListener {

    private RecyclerView recyclerView;
    private InventoryAdapter adapter;

    // Current items being displayed
    private List<InventoryItem> inventoryList;

    // Full list used for filtering (search)
    private List<InventoryItem> fullInventoryList;

    private InventoryDatabaseHelper dbHelper;
    private Button addItemButton, goToSmsButton;
    private EditText searchInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.inventoryRecyclerView);
        addItemButton = findViewById(R.id.addItemButton);
        goToSmsButton = findViewById(R.id.goToSmsButton);
        searchInput = findViewById(R.id.searchInput); // from activity_main.xml

        dbHelper = new InventoryDatabaseHelper(this);

        inventoryList = new ArrayList<>();
        fullInventoryList = new ArrayList<>();
        adapter = new InventoryAdapter(inventoryList, this);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // Load all items from the database
        loadInventory();

        // Add item button
        addItemButton.setOnClickListener(view -> showAddItemDialog());

        // Go to SMS screen button
        goToSmsButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, SmsActivity.class);
            startActivity(intent);
        });

        // Search bar listener
        if (searchInput != null) {
            searchInput.addTextChangedListener(new android.text.TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    // Not needed
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    filterInventory(s.toString());
                }

                @Override
                public void afterTextChanged(android.text.Editable s) {
                    // Not needed
                }
            });
        }
    }

    private void showAddItemDialog() {
        LayoutInflater inflater = LayoutInflater.from(this);
        final View dialogView = inflater.inflate(R.layout.dialog_add_item, null);

        final EditText itemNameInput = dialogView.findViewById(R.id.itemNameInput);
        final EditText itemQuantityInput = dialogView.findViewById(R.id.itemQuantityInput);
        final EditText itemDescriptionInput = dialogView.findViewById(R.id.itemDescriptionInput);

        new AlertDialog.Builder(this)
                .setTitle("Add Inventory Item")
                .setView(dialogView)
                .setPositiveButton("Add", (dialog, which) -> {
                    String name = itemNameInput.getText().toString().trim();
                    String quantityStr = itemQuantityInput.getText().toString().trim();
                    String description = itemDescriptionInput.getText().toString().trim();

                    if (name.isEmpty() || quantityStr.isEmpty() || description.isEmpty()) {
                        Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int quantity;
                    try {
                        quantity = Integer.parseInt(quantityStr);
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Quantity must be a number", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    boolean success = dbHelper.addItem(name, quantity, description);

                    if (success) {
                        Toast.makeText(this, "Item added!", Toast.LENGTH_SHORT).show();
                        loadInventory();
                    } else {
                        Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void loadInventory() {
        inventoryList.clear();
        fullInventoryList.clear();

        Cursor cursor = dbHelper.getAllItems();

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));
                String description = cursor.getString(cursor.getColumnIndexOrThrow("description"));

                InventoryItem item = new InventoryItem(id, name, quantity, description);
                inventoryList.add(item);
                fullInventoryList.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();

        adapter.setItems(inventoryList);
    }

    private void filterInventory(String query) {
        String lowerQuery = query.toLowerCase().trim();

        if (lowerQuery.isEmpty()) {
            // If search box is empty, show full list
            adapter.setItems(fullInventoryList);
            return;
        }

        List<InventoryItem> filteredList = new ArrayList<>();
        for (InventoryItem item : fullInventoryList) {
            String name = item.getName().toLowerCase();
            String description = item.getDescription().toLowerCase();

            if (name.contains(lowerQuery) || description.contains(lowerQuery)) {
                filteredList.add(item);
            }
        }

        adapter.setItems(filteredList);
    }

    @Override
    public void onDeleteClick(int itemId) {
        boolean deleted = dbHelper.deleteItem(itemId);
        if (deleted) {
            Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
            loadInventory();
        } else {
            Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show();
        }
    }
}