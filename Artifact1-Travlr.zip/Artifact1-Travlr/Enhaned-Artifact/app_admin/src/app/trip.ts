export interface Trip {
  name: string;
  code: string;
  length: number;
  start: string;
  resort: string;
  perPerson: number;
}